const calendar = require("../../../../assets/images/calendar/calendar.png")
const clock = require("../../../../assets/images/clock/clock.png")
export const icons = { calendar, clock, }

export type IconName = "calendar"|"clock";

