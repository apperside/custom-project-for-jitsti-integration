declare module "react-native-flip-countdown-timer";
