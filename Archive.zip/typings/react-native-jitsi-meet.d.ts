declare module "react-native-jitsi-meet";
