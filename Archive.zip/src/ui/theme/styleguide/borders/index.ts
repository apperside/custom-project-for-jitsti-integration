import { ThemeBorders, ThemeBorderWidths } from "styled-system";
declare module "styled-system" {

    export interface ThemeBorders {
    }

    export interface ThemeBorderWidths {
    }
}

export const themeBordersMap: ThemeBorders = {
};

export const themeBorderWidthsMap: ThemeBorderWidths = {
};
